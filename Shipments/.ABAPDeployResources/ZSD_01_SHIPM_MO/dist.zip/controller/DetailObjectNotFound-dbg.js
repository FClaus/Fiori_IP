sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("be.ap.project.Shipments.controller.DetailObjectNotFound", {});
});
